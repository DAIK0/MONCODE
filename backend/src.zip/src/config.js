export const TOKEN_SECRET = 'mapaches.2025#';
